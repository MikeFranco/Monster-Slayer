<template>
  <div>
    <MonsterSlayer/>
  </div>
</template>

<script>
import MonsterSlayer from '~/components/MonsterSlayer.vue';

export default {
  components: {
    MonsterSlayer
  }
}
</script>
